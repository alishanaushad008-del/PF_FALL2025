import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext, filedialog
import re
from graphviz import Digraph
import os
import platform
import subprocess

# --- Reserved Symbol ---
EPSILON_SYM = 'epsilon'

# ----------------- Core Conversion Functions -----------------

def parse_nfa_text(text):
    states, alphabet, finals, transitions = set(), set(), set(), {}
    start = None

    lines = [ln.strip() for ln in text.splitlines() if ln.strip() and not ln.startswith('#')]

    for ln in lines:
        if ln.startswith('states:'):
            states = set(x.strip() for x in ln.split(':',1)[1].split(',') if x.strip())
        elif ln.startswith('alphabet:'):
            # Exclude epsilon from the main alphabet if present
            alphabet = set(x.strip() for x in ln.split(':',1)[1].split(',') if x.strip() and x.strip() != EPSILON_SYM)
        elif ln.startswith('start:'):
            start = ln.split(':',1)[1].strip()
        elif ln.startswith('finals:') or ln.startswith('final:'):
            finals = set(x.strip() for x in ln.split(':',1)[1].split(',') if x.strip())

    # Validation
    if not start or start not in states:
        raise ValueError("Invalid or missing start state.")
    if not alphabet:
        raise ValueError("Alphabet missing or only contains epsilon.")
    for f in finals:
        if f not in states:
            raise ValueError(f"Final state '{f}' is not defined in states.")
            
    # Transitions
    valid_symbols = alphabet | {EPSILON_SYM}
    trans_lines = [ln for ln in lines if not ln.startswith(('states:','alphabet:','start:','finals:','final:'))]
    for ln in trans_lines:
        m = re.match(r'(\S+)\s+(\S+)\s*->\s*(.+)', ln)
        if not m: continue
        src, sym, dests = m.group(1), m.group(2), m.group(3)
        dest_set = set(x.strip() for x in re.split(r'[,\s]+', dests) if x.strip())
        
        if src not in states:
            raise ValueError(f"Source state '{src}' undefined.")
        if sym not in valid_symbols:
            raise ValueError(f"Symbol '{sym}' not in alphabet or is not '{EPSILON_SYM}'.")
        for d in dest_set:
            if d not in states:
                raise ValueError(f"Destination state '{d}' undefined.")
        transitions.setdefault(src, {}).setdefault(sym,set()).update(dest_set)
        
    return states, alphabet, start, finals, transitions

def epsilon_closure(state_set, transitions, epsilon_sym=EPSILON_SYM):
    """Calculates the set of states reachable from state_set using only epsilon transitions."""
    closure = set(state_set)
    stack = list(state_set)
    while stack:
        state = stack.pop()
        # Find all destinations reachable from 'state' via epsilon
        epsilon_moves = transitions.get(state, {}).get(epsilon_sym, set())
        for dest in epsilon_moves:
            if dest not in closure:
                closure.add(dest)
                stack.append(dest)
    return frozenset(closure)

def e_nfa_move(state_set, symbol, transitions):
    """
    Computes the set of states reachable from T on input 'symbol' 
    (i.e., ECLOSE(MOVE(ECLOSE(T), symbol))).
    """
    # 1. Start with the epsilon closure of T (already handled implicitly by the construction)
    
    # 2. Perform a move on the actual symbol 'a'
    symbol_move_set = set()
    for s in state_set:
        symbol_move_set |= transitions.get(s, {}).get(symbol, set())
        
    # 3. Take the epsilon closure of the resulting set
    return epsilon_closure(symbol_move_set, transitions)

def nfa_to_dfa(states, alphabet, start, finals, transitions):
    # Initial DFA state is ECLOSE({start})
    start_set = epsilon_closure({start}, transitions)
    
    dfa_states = [start_set]
    dfa_transitions = {}
    dfa_finals = set()
    unmarked = [start_set]
    
    steps = [f"Step 1: Initial state is ECLOSE({{{start}}}) = {format_state(start_set)}"]
    step_count = 2

    while unmarked:
        T = unmarked.pop(0)
        dfa_transitions.setdefault(T,{})
        
        # Check if T contains any NFA final state
        if any(s in finals for s in T):
            dfa_finals.add(T)
            
        for a in sorted(alphabet):
            U = e_nfa_move(T, a, transitions)
            dfa_transitions[T][a] = U
            
            steps.append(f"Step {step_count}: From state {format_state(T)} on symbol '{a}' -> ECLOSE(MOVE({format_state(T)}, '{a}')) = {format_state(U)}")
            step_count +=1
            
            # Add U to the list if it's a new state and not the empty set
            if U not in dfa_states and U:
                dfa_states.append(U)
                unmarked.append(U)
                
    return dfa_states, start_set, dfa_finals, dfa_transitions, steps

def format_state(st):
    if not st: return "∅"
    return "{" + ",".join(sorted(st)) + "}"

# (No change to draw_dfa, open_image, check_graphviz, and the GUI classes)

def draw_dfa(dfa_states, dfa_start, dfa_finals, dfa_transitions, filename='dfa_diagram'):
    dot = Digraph(format='png')
    dot.attr(rankdir='LR', size='8,5', newrank='true')

    mapping = {}
    
    # Define colors
    START_COLOR = '#006400'
    FINAL_COLOR = '#CC0000'
    
    for i, st in enumerate(dfa_states):
        name = f"S{i}"
        mapping[st] = name
        label = format_state(st)
        
        shape = 'doublecircle' if st in dfa_finals else 'circle'
        color = START_COLOR if st==dfa_start else FINAL_COLOR if st in dfa_finals else '#000000'
        
        # Combined label (State + Start/Final info)
        extras = []
        if st == dfa_start: extras.append("Start")
        if st in dfa_finals: extras.append("Final")
        if extras: label += "\n(" + ", ".join(extras) + ")"

        dot.node(name, label, shape=shape, fontname='Arial', fontsize='12', color=color, fontcolor=color, penwidth='2')
        if st==dfa_start:
            dot.node('start', '', shape='point')
            dot.edge('start', name)

    for src, trans in dfa_transitions.items():
        for sym, dest in trans.items():
            if dest:
                penwidth = '2' if dest in dfa_finals else '1'
                dot.edge(mapping[src], mapping[dest], label=sym, fontname='Arial', fontsize='10', penwidth=penwidth)

    outpath = dot.render(filename, cleanup=True)
    return outpath

def open_image(path):
    if platform.system()=='Windows':
        os.startfile(path)
    elif platform.system()=='Darwin':
        subprocess.run(['open', path], check=True)
    else:
        subprocess.run(['xdg-open', path], check=True)

def check_graphviz():
    try:
        subprocess.run(['dot','-V'], check=True, capture_output=True)
        return True
    except (subprocess.CalledProcessError, FileNotFoundError):
        return False

# ----------------- GUI -----------------

class NfaToDfaApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("NFA → DFA Converter")
        self.geometry("1100x850")
        
        self.has_graphviz = check_graphviz()
        if not self.has_graphviz:
            messagebox.showwarning("Dependency Alert", "Graphviz executable ('dot') not found. Diagram generation skipped.")

        # Custom Styling
        s = ttk.Style()
        s.theme_use('clam')
        s.configure('TNotebook.Tab', font=('Segoe UI', 11, 'bold'))
        s.configure('TLabelFrame', font=('Segoe UI', 12, 'bold'))
        s.configure('Accent.TButton', font=('Segoe UI', 10, 'bold'), foreground='dark blue')
        s.configure('Info.TFrame', background='#F0F8FF', borderwidth=2, relief='groove') 
        s.configure('About.TLabel', font=('Segoe UI', 10), background='#F0F8FF')
        
        self.create_widgets()
        
        self.tree.tag_configure('start_state', background='#E0FFE0', font=('Segoe UI',10,'bold'))
        self.tree.tag_configure('final_state', background='#E0F0FF', foreground='#0056B3', font=('Segoe UI',10,'bold'))
        
        self.steps_text.bind("<Key>", self._on_steps_key)

    def _on_steps_key(self, event):
        if event.state & 0x4 or event.keysym in ('Left','Right','Up','Down','Delete','BackSpace','Return'): return None
        return "break"

    def create_widgets(self):
        main_frm = ttk.Frame(self, padding=15)
        main_frm.pack(fill='both', expand=True)
        main_frm.columnconfigure(0,weight=1)
        main_frm.rowconfigure(2,weight=1)

        ## 1. NFA Input Section
        input_frame = ttk.LabelFrame(main_frm,text="📝 Input NFA Definition",padding=10)
        input_frame.grid(row=0,column=0,sticky='ew', pady=(0,15))
        input_frame.columnconfigure(0,weight=1)
        
        self.nfa_text = scrolledtext.ScrolledText(input_frame,height=10,font=('Consolas',10), relief=tk.FLAT)
        self.nfa_text.grid(row=0,column=0,sticky='nsew')
        
        # Updated example with epsilon (which is treated as 'epsilon')
        example=f"""# Example NFA: Accepts strings containing 'ab' or 'ba'
# Use '{EPSILON_SYM}' for epsilon transitions.
states: q0,q1,q2,q3,q4,q5,q6
alphabet: a,b
start: q0
finals: q6
q0 {EPSILON_SYM} -> q1,q4
q1 a -> q2
q2 b -> q3
q3 {EPSILON_SYM} -> q6
q4 b -> q5
q5 a -> q3
"""
        self.nfa_text.insert('1.0',example)

        ## 2. Controls & Status Section (Row 1)
        control_status_frm = ttk.Frame(main_frm)
        control_status_frm.grid(row=1, column=0, sticky='ew', pady=(0, 15))
        control_status_frm.columnconfigure(1, weight=1) # Status box takes remaining width

        # Buttons Frame (Left Side)
        btn_frame = ttk.Frame(control_status_frm)
        btn_frame.grid(row=0, column=0, sticky='w')
        
        # --- DEVELOPER BUTTON ---
        ttk.Button(btn_frame,text="🧑‍💻 About Developers", command=self.show_about_dialog).pack(side='left',padx=15)
        # ---------------------------

        ttk.Button(btn_frame,text="🚀 CONVERT", command=self.on_convert, style='Accent.TButton').pack(side='left',padx=10)
        ttk.Button(btn_frame,text="💾 Save NFA", command=self.save_nfa).pack(side='left',padx=5)
        ttk.Button(btn_frame,text="📂 Load NFA", command=self.load_nfa).pack(side='left',padx=5)
        self.diagram_var = tk.BooleanVar(value=True)
        tk.Checkbutton(btn_frame, text="🖼️ Show DFA Diagram", variable=self.diagram_var).pack(side='left', padx=15)


        # Status Box (Right Side)
        self.status_frame = ttk.LabelFrame(control_status_frm, text="DFA Summary", style='Info.TFrame')
        self.status_frame.grid(row=0, column=1, sticky='ew', padx=(20, 0))
        self.info_label = ttk.Label(self.status_frame, text="Click 'CONVERT' to begin.", justify='left', font=('Segoe UI', 10, 'bold'), background='#F0F8FF')
        self.info_label.pack(fill='both', expand=True, padx=10, pady=5)


        ## 3. Tabbed DFA Output (Row 2)
        self.output_notebook = ttk.Notebook(main_frm)
        self.output_notebook.grid(row=2,column=0,sticky='nsew')

        # --- Tab 1: DFA Table ---
        table_tab = ttk.Frame(self.output_notebook, padding=10)
        self.output_notebook.add(table_tab, text='📋 Transition Table')
        table_tab.columnconfigure(0,weight=1); table_tab.rowconfigure(0,weight=1)
        
        self.tree = ttk.Treeview(table_tab)
        self.tree.grid(row=0,column=0,sticky='nsew')
        vsb = ttk.Scrollbar(table_tab,orient="vertical",command=self.tree.yview); vsb.grid(row=0,column=1,sticky='ns')
        hsb = ttk.Scrollbar(table_tab,orient="horizontal",command=self.tree.xview); hsb.grid(row=1,column=0,sticky='ew')
        self.tree.configure(yscrollcommand=vsb.set,xscrollcommand=hsb.set)

        # --- Tab 2: Steps ---
        steps_tab = ttk.Frame(self.output_notebook, padding=10)
        self.output_notebook.add(steps_tab, text='🪜 Construction Steps')
        steps_tab.columnconfigure(0,weight=1); steps_tab.rowconfigure(0,weight=1)

        self.steps_text = scrolledtext.ScrolledText(steps_tab,height=10,font=('Consolas',10), relief=tk.FLAT)
        self.steps_text.grid(row=0,column=0,sticky='nsew')

    # --- SHOW ABOUT DIALOG ---
    def show_about_dialog(self):
        about_win = tk.Toplevel(self)
        about_win.title("About Developers & Project")
        about_win.geometry("450x250")
        about_win.resizable(False, False)
        about_win.configure(bg='#F0F8FF') 

        frame = ttk.Frame(about_win, padding="20 15 20 15", style='Info.TFrame')
        frame.pack(expand=True, fill='both')

        ttk.Label(frame, text="Project: NFA to DFA Converter", font=('Segoe UI', 14, 'bold'), style='About.TLabel').pack(pady=(0, 10))
        ttk.Label(frame, text="Developed By:", font=('Segoe UI', 12, 'italic'), style='About.TLabel').pack(anchor='w', pady=(5, 5))

        # Developer 1
        dev1_text = "👤 Syed Muhammad Abdul Moiz (23FA-001-CS)"
        ttk.Label(frame, text=dev1_text, font=('Consolas', 11, 'bold'), foreground='#0056B3', style='About.TLabel').pack(anchor='w')

        # Developer 2
        dev2_text = "👤 Prince Irshad (23FA-035-CS)"
        ttk.Label(frame, text=dev2_text, font=('Consolas', 11, 'bold'), foreground='#006400', style='About.TLabel').pack(anchor='w', pady=(5, 20))

        ttk.Label(frame, text="Thank you!", font=('Segoe UI', 10), style='About.TLabel').pack(pady=(5, 0))

        # Center the window over the main window 
        about_win.update_idletasks()
        main_x = self.winfo_x()
        main_y = self.winfo_y()
        main_width = self.winfo_width()
        main_height = self.winfo_height()

        win_width = about_win.winfo_width()
        win_height = about_win.winfo_height()

        x = main_x + int(main_width/2) - int(win_width/2)
        y = main_y + int(main_height/2) - int(win_height/2)
        about_win.geometry(f'+{x}+{y}')
        
        about_win.grab_set()
        self.wait_window(about_win)
        
    def save_nfa(self):
        txt = self.nfa_text.get('1.0','end').strip()
        if not txt: messagebox.showerror("Error","NFA text empty"); return
        path = filedialog.asksaveasfilename(defaultextension='.txt',filetypes=[('Text files','*.txt'),('All files','*.*')])
        if path:
            try: 
                with open(path,'w',encoding='utf-8') as f: f.write(txt)
                messagebox.showinfo("Saved", f"NFA configuration saved to:\n{os.path.basename(path)}")
            except Exception as e: messagebox.showerror("Error",f"Failed to save file: {e}")

    def load_nfa(self):
        path = filedialog.askopenfilename(filetypes=[('Text files','*.txt'),('All files','*.*')])
        if path:
            try:
                with open(path,'r',encoding='utf-8') as f: 
                    self.nfa_text.delete('1.0','end'); self.nfa_text.insert('1.0',f.read())
                messagebox.showinfo("Loaded", f"NFA configuration loaded from:\n{os.path.basename(path)}")
            except Exception as e: messagebox.showerror("Error",f"Failed to load file: {e}")

    def on_convert(self):
        # Clear previous results
        self.tree.delete(*self.tree.get_children())
        self.info_label.config(text="Processing...")
        self.steps_text.delete('1.0','end')
        self.output_notebook.select(0) # Switch to the table tab

        raw = self.nfa_text.get('1.0','end').strip()
        try:
            # 1. Parse and Convert
            states, alphabet, start, finals, transitions = parse_nfa_text(raw)
            # The conversion function now uses the epsilon closure logic
            dfa_states, dfa_start, dfa_finals, dfa_transitions, steps = nfa_to_dfa(states, alphabet, start, finals, transitions)
            
            # 2. Display Results
            self.show_transition_table(dfa_states, alphabet, dfa_start, dfa_finals, dfa_transitions)
            self.steps_text.insert('1.0',"\n".join(steps))
            
            # 3. Generate Diagram
            if self.diagram_var.get():
                if not self.has_graphviz:
                    messagebox.showwarning("Diagram Error", "Graphviz not found. Skipping diagram."); return
                out_png = draw_dfa(dfa_states, dfa_start, dfa_finals, dfa_transitions)
                open_image(out_png)
            
            messagebox.showinfo("Success",f"Conversion complete! {len(dfa_states)} states generated.")

        except Exception as e: 
            messagebox.showerror("Conversion Error ❌",str(e))
            self.info_label.config(text="Conversion Failed! Check Input and console.")
            
    def show_transition_table(self, dfa_states, alphabet, dfa_start, dfa_finals, dfa_transitions):
        cols = ['State'] + sorted(list(alphabet))
        self.tree['columns'] = cols; self.tree['show']='headings'
        
        # Calculate dynamic width for the State column
        max_label_len = max(len(format_state(st)) for st in dfa_states) if dfa_states else 0
        min_width = 300 # Minimum width
        calculated_width = max_label_len * 9 + 100 # Approx. calculation
        
        self.tree.column('State',width=max(min_width, calculated_width),anchor='w')
        self.tree.heading('State',text='DFA State (NFA Subset)')

        for col in sorted(list(alphabet)): 
            self.tree.column(col,width=100,anchor='center'); 
            self.tree.heading(col,text=f"On '{col}'")

        for i, st in enumerate(dfa_states):
            state_label = format_state(st)
            tags = []
            if st==dfa_start: tags.append('start_state'); state_label = "➡️ " + state_label
            if st in dfa_finals: tags.append('final_state'); state_label += " 🌟"
            
            # Ensure transitions are calculated correctly using the new logic
            row = [state_label] + [format_state(dfa_transitions.get(st,{}).get(a,frozenset())) for a in sorted(alphabet)]
            self.tree.insert('','end',iid=str(i),values=row,tags=tuple(tags))

        # Update Info Box
        info_text = (
            f"Total DFA States: {len(dfa_states)}\n"
            f"Start State: {format_state(dfa_start)} ➡️\n"
            f"Final States: {', '.join(format_state(s) for s in dfa_finals) or 'None'} 🌟"
        )
        self.info_label.config(text=info_text)


if __name__=='__main__':
    app = NfaToDfaApp()
    app.mainloop()